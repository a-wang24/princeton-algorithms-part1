import java.util.ArrayList;
import java.util.Arrays;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

/**
 * @author Alan
 * 
 * Coursera: Princeton Algorithms and Data Structures 1
 * collinear - bruteforce solution for finding collinear points from a set of points
 * 
 */

public class FastCollinearPoints {
	//* Array of found line segements *//
	private LineSegment[] segments;
	
	//* Constructor *//
	public FastCollinearPoints(Point[] points) {
		if (points == null) throw new IllegalArgumentException("Null array");
		checkPoints(points);
		
		Point[] pointsCopy = Arrays.copyOf(points, points.length);
		ArrayList<LineSegment> foundSegments = new ArrayList<>();
		
		for (Point p : points) {
			Arrays.sort(pointsCopy, p.slopeOrder());
			double slope = 0;
			double previousSlope = Double.NEGATIVE_INFINITY;
			int count = 0;
			
			// Start at i = 1 bc first entry will be p itself
			for (int i = 1; i < pointsCopy.length; i++) {
				slope = p.slopeTo(pointsCopy[i]);
				if (slope - previousSlope == 0) {
					count++;
				} else {
					if (count >= 3) {
						foundSegments.add(new LineSegment(p, pointsCopy[i-1]));
					}
					count = 0;
				}
				previousSlope = slope;
			}
			
			if (count >= 3) {
				foundSegments.add(new LineSegment(p, pointsCopy[pointsCopy.length-1]));
			}
			
		}
		
		segments = foundSegments.toArray(new LineSegment[foundSegments.size()]);
	}
	
	//* returns number of line segments *//
	public int numberOfSegments() {
		return segments.length;
	}
	
	//* returns array of found line segments *//
	public LineSegment[] segments() {
		return segments;
	}
	
	//* adds segment to list if not already in list *//
	private void addSegmentIfNew() {
		
	}
	
	//* helper function to check if there are repeated points in the constructor argument *//
	private void checkPoints(Point[] points) {
		for (int i=0; i < points.length; i++) {
			for (int j=i+1; j < points.length; j++) {
				if (points[i] == null) throw new IllegalArgumentException("Null point in array");
				if (points[i].compareTo(points[j]) == 0) throw new IllegalArgumentException("Repeated points");
			}
		}
	}
	
	public static void main(String[] args) {
		// read points in from file
		In in = new In(args[0]);
		int n = in.readInt();
		Point[] points = new Point[n];
		for (int i = 0; i < n; i++) {
			int x = in.readInt();
			int y = in.readInt();
			points[i] = new Point(x,y);
		}
		
		// draw the points
	    StdDraw.enableDoubleBuffering();
	    StdDraw.setXscale(0, 32768);
	    StdDraw.setYscale(0, 32768);
	    for (Point p : points) {
	        p.draw();
	    }
	    StdDraw.show();
	    
	    // print and draw line segments
	    BruteCollinearPoints collinear = new BruteCollinearPoints(points);
	    StdOut.println(collinear.numberOfSegments());
	    for (LineSegment segment : collinear.segments()) {
	    	StdOut.println(segment);
	    	segment.draw();
	    }
	    StdDraw.show();
	}
}
